<?php
$THEME_NAME = "Classic";
?>